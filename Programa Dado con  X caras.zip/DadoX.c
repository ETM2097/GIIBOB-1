#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
//Vamos a creat un programa quesimule un dado de X caras, para ello usaremos la función rand () y obtendremos el resto entre este número aleatorio y las caras que deseemosn tener.
int main() {
    //Declararemmos las variables que usaremos para el programa. "Caras" para el número de caras que tendrá nuestro dado y "número" para almacenar el número aleatorio de la función rand().
    int caras, numero, repes;
    //Pediremos el número de caras para nuestro dado.
    printf("Introduce el número de caras deseado para tu dado virtual\n");
    scanf("%d", &caras);
    if (caras < 1){
        printf("El número de caras ha de ser mayor a 1\n");
        return 1;
    }
    //Pediremos además cuantas veces se quiere lanzar el dado.
    printf("Introduce cuantas veces deseas repetir el lanzamiento de tu dado|¡\n");
    scanf("%d", &repes);
    //Usaremos una semilla basada en el tiempo actual para que la función rand() nos de distintos valores cada vez que la ejecutemos.
    srand(time NULL);
 for (int i = 0; i < repes; i++) {
    // Genera un número aleatorio entre 0 y caras - 1.
    numero = rand() % caras;
    //Añadimos 1 a número para que coincida el número obtenido con el valor real de la cara, ya que el valor 0 indica la cara 1, por ejemplo..
    numero++;
    // Mostrar el resultado
    printf("Resultado del lanzamiento: %d\n", numero);

    // Esperar 2 segundos al siguiente resultado
    sleep(2);
}
    return 0;
}
